"""
SiCooperative Data Lake POC - ETL Pipeline
Desafio Técnico - Engenharia de Dados

Este pacote contém o pipeline ETL para extração, transformação e carga
de dados de movimentações de cartões da SiCooperative LTDA.
"""

__version__ = "1.0.0"
__author__ = "Desafio Técnico - Engenharia de Dados"
