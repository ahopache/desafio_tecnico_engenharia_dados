# Observabilidade e Métricas - SiCooperative ETL

## Visão Geral

Este documento descreve o sistema de observabilidade implementado no pipeline ETL, incluindo métricas de performance, tempos de execução e integração opcional com sistemas de monitoramento externos como Prometheus.

## Arquitetura

### Componentes Principais

1. **Módulo de Observabilidade** (`src/observability.py`)
   - `MetricsCollector`: Coletor de métricas em memória
   - `ObservabilityManager`: Gerenciador de observabilidade
   - `TimerResult`: Resultados de medições de tempo
   - `MetricPoint`: Ponto individual de métrica

2. **Integração no Pipeline** (`src/etl_pipeline.py`)
   - Medição de tempo por etapa (extract, transform, load)
   - Contadores de registros processados
   - Métricas de qualidade de dados
   - Logs estruturados

3. **Exportadores**
   - **JSON**: Para análise local e depuração
   - **Prometheus**: Para integração com sistemas de monitoramento

## Métricas Coletadas

### Métricas de Tempo

| Métrica | Descrição | Labels | Tipo |
|---------|-----------|--------|------|
| `etl_duration_seconds` | Duração de operações específicas | `timer_id`, metadados | Gauge |
| `etl_stage_duration_seconds` | Duração de cada etapa do pipeline | `stage` | Gauge |
| `etl_pipeline_duration_seconds` | Duração total do pipeline | `status` | Gauge |
| `etl_quality_check_duration_seconds` | Tempo gasto em verificações de qualidade | `check_name`, `status` | Gauge |

### Métricas de Contadores

| Métrica | Descrição | Labels | Tipo |
|---------|-----------|--------|------|
| `etl_timer_total` | Número de timers executados | `timer_id` | Counter |
| `etl_stage_total` | Número de execuções por etapa | `stage` | Counter |
| `etl_quality_checks_total` | Número total de verificações | `stage` | Counter |
| `etl_errors_total` | Número de erros ocorridos | `error_type` | Counter |

### Métricas de Volume

| Métrica | Descrição | Labels | Tipo |
|---------|-----------|--------|------|
| `etl_records_input` | Registros de entrada por etapa | `stage` | Gauge |
| `etl_records_output` | Registros de saída por etapa | `stage` | Gauge |
| `etl_throughput_records_per_second` | Taxa de processamento | `stage` | Gauge |

### Métricas de Qualidade

| Métrica | Descrição | Labels | Tipo |
|---------|-----------|--------|------|
| `etl_quality_checks_total` | Total de verificações | `stage` | Gauge |
| `etl_quality_checks_failed` | Verificações que falharam | `stage` | Gauge |
| `etl_quality_checks_warnings` | Avisos de qualidade | `stage` | Gauge |

## Configuração

### Variáveis de Ambiente

```bash
# Controle geral da observabilidade
OBSERVABILITY_ENABLED=true

# Prometheus Pushgateway (opcional)
PROMETHEUS_GATEWAY_URL=http://localhost:9091
PROMETHEUS_JOB_NAME=sicooperative-etl

# Logs detalhados
METRICS_DETAILED_LOGGING=false

# Arquivo de exportação
METRICS_EXPORT_FILE=pipeline_metrics.json
```

### Exemplo de Configuração (.env)

```bash
# Observabilidade habilitada
OBSERVABILITY_ENABLED=true

# Prometheus (opcional)
PROMETHEUS_GATEWAY_URL=http://localhost:9091
PROMETHEUS_JOB_NAME=sicooperative-etl

# Logs detalhados para debug
METRICS_DETAILED_LOGGING=true

# Exportar métricas para arquivo
METRICS_EXPORT_FILE=pipeline_metrics.json
```

## Uso Programático

### Coletor Básico

```python
from observability import observability_manager

# Verificar se observabilidade está habilitada
if observability_manager.is_enabled():
    collector = observability_manager.get_collector()

    # Iniciar medição
    timer_id = collector.start_timer("minha_operacao")

    # Operação a ser medida
    # ... código aqui ...

    # Parar medição
    result = collector.stop_timer(timer_id)
    print(f"Operação levou {result.duration_seconds:.3f}s")

    # Registrar métrica customizada
    collector.record_gauge("minha_metrica", valor, {"label": "valor"})
```

### Integração no Pipeline

```python
# No pipeline ETL (já integrado automaticamente)
# Etapas medidas automaticamente:
# - spark_session_creation
# - mysql_connection_validation
# - extract_stage
# - quality_checks
# - transform_stage
# - load_stage
# - pipeline_total

# Métricas registradas automaticamente:
# - Tempos de execução
# - Contadores de registros
# - Métricas de qualidade
# - Taxas de throughput
```

## Formatos de Exportação

### Formato JSON

```json
{
  "summary": {
    "total_metrics": 45,
    "total_timers": 7,
    "total_duration_seconds": 125.432,
    "average_duration_seconds": 17.919,
    "collection_timestamp": "2023-10-15T14:30:00"
  },
  "metrics": [
    {
      "name": "etl_stage_duration_seconds",
      "value": 15.234,
      "timestamp": 1697370600.123,
      "labels": {"stage": "extract"},
      "type": "gauge"
    }
  ],
  "timers": [
    {
      "name": "extract_stage",
      "duration_seconds": 15.234,
      "start_time": 1697370584.889,
      "end_time": 1697370600.123,
      "metadata": {}
    }
  ]
}
```

### Formato Prometheus

```
# HELP etl_stage_duration_seconds Duração de cada etapa do pipeline
# TYPE etl_stage_duration_seconds gauge
etl_stage_duration_seconds{stage="extract"} 15.234
etl_stage_duration_seconds{stage="transform"} 45.123
etl_stage_duration_seconds{stage="load"} 8.567

# HELP etl_records_output Registros de saída por etapa
# TYPE etl_records_output gauge
etl_records_output{stage="extract"} 50000
etl_records_output{stage="transform"} 50000
etl_records_output{stage="load"} 50000
```

## Integração com Prometheus

### Pushgateway

Para enviar métricas para o Prometheus via Pushgateway:

1. **Configure o ambiente**:
```bash
export PROMETHEUS_GATEWAY_URL=http://localhost:9091
export PROMETHEUS_JOB_NAME=sicooperative-etl
```

2. **Execução automática**: O pipeline envia métricas automaticamente se configurado

3. **Verificação**: As métricas aparecerão no Prometheus com o job name configurado

### Configuração do Prometheus

Arquivo `prometheus.yml` de exemplo incluído no projeto:

```yaml
scrape_configs:
  - job_name: 'sicooperative-etl'
    static_configs:
      - targets: ['pushgateway:9091']
```

### Dashboards Grafana

Exemplo de queries para dashboards:

```promql
# Tempo médio por etapa
avg(etl_stage_duration_seconds) by (stage)

# Taxa de sucesso do pipeline
rate(etl_pipeline_duration_seconds[5m])

# Volume de dados processados
sum(etl_records_output) by (stage)

# Erros por tipo
sum(etl_errors_total) by (error_type)

# Qualidade dos dados
etl_quality_checks_failed / etl_quality_checks_total
```

## Logs Estruturados

### Exemplo de Log

```
INFO - 📊 RESUMO DE MÉTRICAS DO PIPELINE
INFO - ============================================================
INFO - ⏱️ Duração total: 125.432s
INFO - 📈 Média por etapa: 17.919s
INFO - 🔢 Total de métricas: 45
INFO - ⏳ Timers executados: 7
INFO - 📅 Timestamp: 2023-10-15T14:30:00
INFO - ============================================================
```

### Logs Detalhados (se habilitado)

```
DEBUG - Métrica registrada: etl_records_output=50000 {"stage": "extract"}
DEBUG - Timer iniciado: extract_stage (ID: extract_stage_1697370584)
DEBUG - Timer finalizado: extract_stage = 15.234s
```

## Benefícios

### Monitoramento em Tempo Real
- ✅ Tempos de execução por etapa
- ✅ Volume de dados processados
- ✅ Taxas de throughput
- ✅ Status de qualidade dos dados

### Análise de Performance
- ✅ Identificação de gargalos
- ✅ Tendências de performance
- ✅ Comparação entre execuções
- ✅ Otimização baseada em dados

### Detecção de Anomalias
- ✅ Mudanças drásticas de volume
- ✅ Degradação de performance
- ✅ Problemas de qualidade de dados
- ✅ Falhas críticas

### Integração Empresarial
- ✅ Compatível com Prometheus
- ✅ Dashboards no Grafana
- ✅ Alertas automatizados
- ✅ Relatórios executivos

## Troubleshooting

### Problemas Comuns

1. **Métricas não aparecem no Prometheus**
   - Verificar se `PROMETHEUS_GATEWAY_URL` está configurada
   - Confirmar se o Pushgateway está rodando
   - Checar logs de erro de conexão

2. **Performance impactada**
   - Desabilitar métricas detalhadas: `METRICS_DETAILED_LOGGING=false`
   - Reduzir frequência de medições se necessário
   - Usar amostragem para métricas de alta frequência

3. **Dados inconsistentes**
   - Verificar sincronização de timestamps
   - Validar configurações de timezone
   - Checar consistência de labels

### Métricas de Debug

Para debug avançado, habilite logs detalhados:

```bash
export METRICS_DETAILED_LOGGING=true
export LOG_LEVEL=DEBUG
```

## Extensibilidade

### Adicionar Nova Métrica

```python
# No código do pipeline
observability_manager.get_collector().record_gauge(
    "minha_metrica_customizada",
    valor,
    {"minha_label": "valor"}
)
```

### Novo Tipo de Timer

```python
# Medir operação customizada
timer_id = observability_manager.get_collector().start_timer(
    "operacao_customizada",
    {"parametro": "valor"}
)
# ... código ...
result = observability_manager.get_collector().stop_timer(timer_id)
```

### Integração com Outros Sistemas

O sistema é facilmente extensível para outros coletores:

```python
# Exemplo: integração com DataDog
def export_to_datadog(self):
    # Implementação customizada
    pass

# Exemplo: integração com New Relic
def export_to_newrelic(self):
    # Implementação customizada
    pass
```

## Conclusão

O sistema de observabilidade implementado fornece:

- ✅ **Visibilidade completa** do pipeline ETL
- ✅ **Métricas acionáveis** para otimização
- ✅ **Integração pronta** com ferramentas empresariais
- ✅ **Baixo overhead** de performance
- ✅ **Facilidade de extensão** para novas métricas

Permite monitoramento proativo, identificação rápida de problemas e tomada de decisões baseada em dados concretos sobre o desempenho do pipeline.
