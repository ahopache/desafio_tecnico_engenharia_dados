"""
Testes Unitários - SiCooperative Data Lake POC
"""

__version__ = "1.0.0"
