# Scripts SQL - SiCooperative Data Lake POC

Este diretório contém os scripts SQL para criação e população do banco de dados MySQL.

## 📄 Arquivos

### **01_create_schema.sql** (270 linhas)
**DDL - Criação do Schema**

Cria toda a estrutura do banco de dados:
- ✅ Database `sicooperative_db`
- ✅ 4 Tabelas normalizadas (3FN):
  - `associado` - Clientes da cooperativa
  - `conta` - Contas bancárias
  - `cartao` - Cartões vinculados às contas
  - `movimento` - Transações dos cartões

**Features:**
- ✅ Foreign keys com ON DELETE RESTRICT e ON UPDATE CASCADE
- ✅ Check constraints (idade, email, saldo, valores)
- ✅ Índices otimizados para queries de JOIN
- ✅ View `vw_movimento_completo` (visão consolidada)
- ✅ Stored Procedure `sp_estatisticas_associado`
- ✅ Function `fn_total_transacoes_cartao`
- ✅ Charset UTF-8 (utf8mb4_unicode_ci)

### **02_insert_data.sql** (~3800 linhas)
**DML - Inserção de Dados Fictícios**

Popula o banco com dados realistas gerados pelo Faker:
- ✅ **100 associados** com nomes brasileiros
- ✅ **193 contas** (média de 2 por associado)
- ✅ **264 cartões** com números válidos
- ✅ **3166 movimentos** com estabelecimentos reais

**Dados Realistas:**
- ✅ Nomes e sobrenomes brasileiros (Faker pt_BR)
- ✅ Estabelecimentos reais de Porto Alegre:
  - Zaffari, Carrefour, Big, Nacional
  - Posto Ipiranga, Uber, 99 Taxi
  - Farmácia Panvel, Hospital Moinhos de Vento
  - Renner, C&A, Zara
  - Cinemark, Bar Ocidente, Teatro São Pedro
- ✅ Categorias: alimentação, transporte, saúde, educação, lazer, vestuário, moradia, serviços
- ✅ Valores proporcionais às categorias
- ✅ Datas nos últimos 365 dias

### **generate_fake_data.py** (440 linhas)
**Gerador de Dados com Faker**

Script Python para regenerar o arquivo `02_insert_data.sql` com novos dados:

```bash
# Gerar novos dados
python sql/generate_fake_data.py

# Isso sobrescreve: sql/02_insert_data.sql
```

**Configurável:**
- Quantidade de associados (padrão: 100)
- Média de contas por associado (padrão: 2)
- Movimentos por cartão (padrão: 10)
- Seed para reprodutibilidade (padrão: 42)

---

## 🚀 Como Usar

### **Opção 1: Execução Manual**

```bash
# 1. Criar schema
mysql -u root -p < sql/01_create_schema.sql

# 2. Popular com dados
mysql -u root -p < sql/02_insert_data.sql
```

### **Opção 2: Docker (Automático)**

Os scripts são executados automaticamente na inicialização do container MySQL:

```bash
cd docker
docker-compose up -d

# Os scripts em /docker-entrypoint-initdb.d são executados em ordem:
# 1. 01_create_schema.sql
# 2. 02_insert_data.sql
```

### **Opção 3: Regenerar Dados**

```bash
# Instalar Faker
pip install faker

# Gerar novos dados
python sql/generate_fake_data.py

# Aplicar no banco
mysql -u root -p sicooperative_db < sql/02_insert_data.sql
```

---

## 📊 Modelo de Dados

### **Relacionamentos**

```
┌─────────────┐
│  associado  │
│  (100)      │
└──────┬──────┘
       │ 1
       │
       │ N
┌──────┴──────┐
│    conta    │
│    (193)    │
└──────┬──────┘
       │ 1
       │
       │ N
┌──────┴──────┐
│   cartao    │
│   (264)     │
└──────┬──────┘
       │ 1
       │
       │ N
┌──────┴──────┐
│  movimento  │
│   (3166)    │
└─────────────┘
```

### **Tabelas**

| Tabela | Registros | Descrição |
|--------|-----------|-----------|
| `associado` | 100 | Clientes (nome, sobrenome, idade, email) |
| `conta` | 193 | Contas bancárias (tipo, saldo, data_criacao) |
| `cartao` | 264 | Cartões (número, nome_impresso, validade, limite) |
| `movimento` | 3166 | Transações (valor, descrição, data, categoria) |

---

## 🔧 Personalização

### **Modificar Quantidade de Dados**

Edite `generate_fake_data.py`:

```python
# Linha 298: Quantidade de associados
associados = generate_associados(200)  # Alterar de 100 para 200

# Linha 302: Média de contas por associado
contas = generate_contas(associados, media_contas_por_associado=3)

# Linha 310: Movimentos por cartão
movimentos = generate_movimentos(cartoes, num_movimentos_por_cartao=20)
```

### **Adicionar Estabelecimentos**

Edite a função `generate_movimentos()`:

```python
categorias_estabelecimentos = {
    'alimentacao': [
        'Zaffari', 'Carrefour', 'Big',
        'Seu Novo Estabelecimento'  # Adicionar aqui
    ],
    # ...
}
```

### **Mudar Seed (Dados Diferentes)**

```python
# Linha 12-13
Faker.seed(123)  # Alterar de 42 para outro número
random.seed(123)
```

---

## 📝 Notas Importantes

### **Ordem de Execução**
Os scripts **devem** ser executados em ordem:
1. `01_create_schema.sql` (cria estrutura)
2. `02_insert_data.sql` (popula dados)

### **Truncate vs Drop**
O `02_insert_data.sql` usa `TRUNCATE` para limpar dados existentes, mantendo a estrutura das tabelas.

### **Foreign Keys**
As foreign keys garantem integridade referencial:
- Não é possível deletar um associado com contas
- Não é possível deletar uma conta com cartões
- Não é possível deletar um cartão com movimentos

### **Performance**
- Inserts em lotes de 1000 registros
- Índices criados após inserção
- `SET AUTOCOMMIT = 0` para transações em lote

---

## 🐛 Troubleshooting

### **Erro: "Table already exists"**
```bash
# Dropar database e recriar
mysql -u root -p -e "DROP DATABASE IF EXISTS sicooperative_db;"
mysql -u root -p < sql/01_create_schema.sql
```

### **Erro: "Duplicate entry"**
```bash
# Limpar dados e reinserir
mysql -u root -p sicooperative_db -e "TRUNCATE TABLE movimento; TRUNCATE TABLE cartao; TRUNCATE TABLE conta; TRUNCATE TABLE associado;"
mysql -u root -p < sql/02_insert_data.sql
```

### **Erro: "Cannot delete or update a parent row"**
```bash
# Desabilitar foreign key checks temporariamente
mysql -u root -p sicooperative_db -e "SET FOREIGN_KEY_CHECKS = 0; TRUNCATE TABLE movimento; TRUNCATE TABLE cartao; TRUNCATE TABLE conta; TRUNCATE TABLE associado; SET FOREIGN_KEY_CHECKS = 1;"
```

---

## 📚 Referências

- [MySQL Documentation](https://dev.mysql.com/doc/)
- [Faker Documentation](https://faker.readthedocs.io/)
- [Faker pt_BR Provider](https://faker.readthedocs.io/en/master/locales/pt_BR.html)
